package com.jin.AWS;

public interface IAWSService {
	public String getRegionName();
}
